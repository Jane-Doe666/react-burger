export const OPEN_INGREDIENT = "INGREDIENT_DETAILS/OPEN_INGREDIENT";

export const openIngredientInfo = (info) => ({
	type: OPEN_INGREDIENT,
	info,
});
